import React from 'react'
export default function MangaList({ mangas }) {
  if (!mangas.length) return <p className="text-center">لا توجد نتائج</p>
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {mangas.map(m => (
        <div key={m.id} className="border rounded p-2 bg-white">
          <img src={m.cover} alt={m.title} className="w-full h-48 object-cover rounded" />
          <h3 className="mt-2 font-semibold">{m.title}</h3>
          <p>فصول: {m.chapters}</p>
          <a href={m.url} target="_blank" className="text-pink-600">رابط القراءة</a>
        </div>
      ))}
    </div>
  )
}