import React, { useState } from 'react'

const GENRES = [
  { label: 'أكشن', code: 'action' },
  { label: 'رومانسي', code: 'romance' },
  { label: 'فانتازيا', code: 'fantasy' },
  { label: 'مدرسي', code: 'school_life' },
  { label: 'كوميدي', code: 'comedy' },
  { label: 'رعب', code: 'horror' },
  { label: 'غموض', code: 'mystery' }
]

export default function SearchForm({ onSearch }) {
  const [selected, setSelected] = useState([])
  const [minCh, setMinCh] = useState(0)
  return (
    <div className="mb-4">
      <div className="flex gap-2 mb-2 flex-wrap">
        {GENRES.map(g => (
          <button
            key={g.code}
            className={\`px-3 py-1 rounded \${selected.includes(g.code) ? 'bg-pink-400 text-white' : 'bg-white border'}\`}
            onClick={() =>
              setSelected(prev => prev.includes(g.code)
                ? prev.filter(x => x !== g.code)
                : [...prev, g.code])
            }
          >{g.label}</button>
        ))}
      </div>
      <div className="mb-2">
        <label>عدد الفصول من:</label>
        <input
          type="number" value={minCh}
          onChange={e => setMinCh(+e.target.value)}
          className="border rounded p-1 w-20"
        />
      </div>
      <button onClick={() => onSearch({ genres: selected, minChapters: minCh })}
        className="bg-pink-500 text-white px-4 py-2 rounded">
        بحث
      </button>
    </div>
  )
}