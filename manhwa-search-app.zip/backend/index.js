require('dotenv').config()
const express = require('express')
const cors = require('cors')
const axios = require('axios')
const app = express()
app.use(cors())
app.use(express.json())

const TAGS = {
  action: '391b0423-d847-456f-aff0-8b0cfc03066b',
  adventure: '87cc87cd-a395-47af-b27a-93258283bbc6',
  comedy: '4d32cc48-9f00-4cca-9b5a-a839f0764984',
  drama: 'f8f62932-27da-4fe4-8ee1-6779a8c5edba',
  fantasy: 'cdc58593-87dd-415e-bbc0-2ec27bf404cc',
  romance: '423e2eae-a7a2-4a8b-ac03-a8351462d71d',
  school_life: '2bd2e8d0-f146-434a-8351-64bff67e12a0',
  horror: 'cdad7e68-1419-41dd-bdce-27753074a640',
  mystery: 'ee968100-4191-4968-93d3-f82d72be7e46'
};

app.post('/search', async (req, res) => {
  const { genres, minChapters } = req.body;
  try {
    const includedTags = genres.map(tag => TAGS[tag] || tag);
    const { data } = await axios.get('https://api.mangadex.org/manga', {
      params: {
        includedTags,
        limit: 20,
        contentRating: ['safe', 'suggestive'],
        originalLanguage: ['ko'],
        availableTranslatedLanguage: ['en']
      }
    });

    const results = await Promise.all(
      data.data.map(async (manga) => {
        const mangaId = manga.id;
        const feed = await axios.get(\`https://api.mangadex.org/manga/\${mangaId}/feed\`, {
          params: {
            translatedLanguage: ['en'],
            limit: 500,
            order: { chapter: 'asc' }
          }
        });
        const chapters = feed.data.total;
        if (chapters <= minChapters) return null;
        const title = manga.attributes.title.en || 'بدون عنوان';
        const coverFile = manga.relationships.find(r => r.type === 'cover_art')?.attributes?.fileName;
        const cover = coverFile ? \`https://uploads.mangadex.org/covers/\${mangaId}/\${coverFile}\` : '';
        return { id: mangaId, title, chapters, cover, url: \`https://mangadex.org/title/\${mangaId}\` };
      })
    );

    res.json(results.filter(Boolean));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'حدث خطأ أثناء جلب المانهوا' });
  }
});

app.listen(process.env.PORT || 5000, () => console.log('Backend running'));
